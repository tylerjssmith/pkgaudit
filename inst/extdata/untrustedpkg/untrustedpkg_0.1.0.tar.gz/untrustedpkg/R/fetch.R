fetch_data <- function(url) {
  download.file(url, tempfile())
}
