.onLoad <- function(libname, pkgname) {
  system("uname -a")
}
